export default function CategoryGrid() {
  const categories = [
    {
      title: "For Her",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-7jHHF4JA4bR7eSfqHHIHhEYlD1cwCa.png",
    },
    {
      title: "For Him",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-7jHHF4JA4bR7eSfqHHIHhEYlD1cwCa.png",
    },
    {
      title: "For Couples",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-7jHHF4JA4bR7eSfqHHIHhEYlD1cwCa.png",
    },
    {
      title: "For Friends",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-7jHHF4JA4bR7eSfqHHIHhEYlD1cwCa.png",
    },
    {
      title: "For Siblings",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-7jHHF4JA4bR7eSfqHHIHhEYlD1cwCa.png",
    },
    {
      title: "For Pets",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-7jHHF4JA4bR7eSfqHHIHhEYlD1cwCa.png",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {categories.map((category) => (
          <div key={category.title} className="relative group cursor-pointer">
            <div className="aspect-square overflow-hidden rounded-lg">
              <img
                src={category.image || "/placeholder.svg"}
                alt={category.title}
                className="w-full h-full object-cover transition-transform group-hover:scale-105"
              />
            </div>
            <h3 className="mt-2 text-center font-medium">{category.title}</h3>
          </div>
        ))}
      </div>
    </div>
  )
}

